/*Data Insert into Patient Table*/

INSERT INTO `patient` VALUES 	(1,'Jamal'),
					(2,'Zainab'),
					(3,'Armeen'),
					(4,'Ayyan'),
					(5,'Arsalan'),
					(6,'Qais'),
					(7,'Rashid'),
					(8,'Talha');




/*Data Insert into Address Table*/

INSERT INTO `address` VALUES 	('Main Street Tahir Colony Rahim Yar Khan',1),
					('Queens Road Sukkur',2),
					('Dera Bughti Balochistan',4),
					('Basti Larkana',5),
					('Shikar Pur Sindh',6);



/*Data Insert into Contact_no Table*/

INSERT INTO `contact_no` VALUES 	('03077923020',1), 
						('03006753537',3), 
						('03457163521',4), 
						('06878965431',5);

/*Data Insert Into Doctor Table*/

INSERT INTO doctor(name, address)
VALUES ('Dr. Yousufullah Khan', 	'MVW6+MRC, Kamangar Mohalla, Sukkur, Sindh'),
	 ('Dr. Anwar Aehmad Ansari',	'MVR7+6XC, Tariq Rd, Sukkur, Sindh'),
	 ('Dr. Laraib',			'MVR6+H3J, Sukkur, Sindh');


/*Data Insert Into Appointment*/

INSERT INTO appointment(due_amount, app_status, pay_status, pid, date_time)
VALUES 	(10, 'cancel', 'not-paid', 1, '2022-03-25 11:40:00'),
		(110, 'booked', 'not-paid', 2, '2022-03-25 12:40:00'),
		(10, 'cancel', 'not-paid', 3, '2022-01-23 10:40:00'),
		(170, 'visited', 'not-paid', 4, '2022-03-25 14:40:00'),
		(130, 'booked', 'paid', 5, '2022-07-25 10:40:00'),
		(90, 'booked', 'paid', 5, '2022-06-25 10:40:00'),
		(70, 'booked', 'not-paid', 5, '2022-05-25 10:40:00'),
		(0, 'reffered', 'paid', 7, '2022-07-25 10:40:00'),
		(0, 'reffered', 'paid', 8, '2022-04-25 10:40:00'),
		(75, 'visited', 'paid', 4, '2022-01-25 10:40:00');


/*Data Insert Into Reffered*/

INSERT INTO refferal_patients(aid, did)
VALUES	(8,1),
		(9,3);


/*Data Insert Into Treatment*/

INSERT INTO treatment	(aid, details)
VALUES			(4,'Acefyl Tables, Cought Syrup'),
				(4,'Zentax, Insulin, Sugar');

/*Data Insert Into fee_guidlines*/

INSERT INTO fee_guidelines(description)
VALUES			  ('30$ per mint and Cancellation Fee is 10$'),
				  ('50$ per mint and Cancellation Fee is 30$'),
				  ('24$ per mint and Cancellation Fee is 40$');

/*Data Insert Into Payment*/

INSERT INTO payment(fgid, aid)
VALUES	(1,1),
		(1,2),
		(1,3),
		(2,4),
		(2,5),
		(2,6),
		(3,7),
		(3,8),
		(3,9),
		(3,10),

/*Data Insert Into Installment*/

INSERT INTO installments(payment_type, amount, date_time, pay_id)
	VALUE			(cash, 50.0, '2022-02-03 01:01:00', 5),
				('post', 80, '2022-02-03 01:01:00', 5),
				('card', 90, '2022-02-03 01:01:00', 6),
				('cash', 75, '2022-03-04 01:01:00', 10);

/*

new appointment into the diary

INSERT INTO appointment(due_amount, app_status, pay_status, pid, date_time)
VALUES 	(10, 'cancel', 'not-paid', 1, '2022-03-25 11:40:00');	

*/	

/*
 
she makes a new chart for 
the patient and puts it into the charts filing cabinet

INSERT INTO patient(name) 
VALUES 	( ? );

INSERT INTO address(address, pid) 
VALUES 	( ? , ? );

INSERT INTO contact_no(contact, pid)
VALUES 	( ? , ? ), 

*/


/*
Sometimes patients contact Helen to rearrange or even cancel appointments.

this if for cancel and run both querie at a time to add cancellation fee
and set statu to cancel

UPDATE appointment SET app_status='cancel' WHERE aid= ? ;
UPDATE appointment SET due_amount=10 WHERE aid= ? ;
	
*/

/*
Helen checks the appointment diary and makes a list of all next 
week's appointments

 SELECT * FROM appointment a
	JOIN patient p ON a.pid = p.pid
	JOIN address ad ON ad.pid = a.pid
  	WHERE WEEK(date_time)=WEEK(NOW()+1);
*/

/*
Appointment Card

SELECT * FROM appointment a
	JOIN patient p ON a.pid = p.pid
	JOIN address ad ON ad.pid = a.pid
	JOIN treatment t ON t.aid = a.aid
  	WHERE WEEK(date_time)=WEEK(NOW()+1) AND aid = ?;

*/


/*
she prepares bills by searching the patient charts to 
find details of any unpaid treatments.

SELECT * FROM appointment a
JOIN patient p ON a.pid = p.pid
JOIN address ad ON ad.pid = p.pid
WHERE pay_status='not-paid';

*/

/*
Treatment fee Guidlines

SELECT * FROM fee_guidlines;

*/

/*
The bills, itemising all unpaid treatments and 
late cancellations

SELECT * FROM payment pay
JOIN fee_guidelines fg ON fg.fgid = pay.fgid
JOIN appointment a ON pay.aid = a.aid
JOIN patient p ON a.pid = p.pid
JOIN address ad ON ad.pid = p.pid
WHERE a.pay_status='not-paid' OR a.app_status='cancel';

*/

/*
Treatments which have been paid for are marked 
as such in the patient's file so that they will not be billed again

UPDATE appointment SET pay_status='paid' WHERE aid= ? ;

*/

/*
Check Total Amount Paid

SELECT (due_amount-(
			SELECT SUM(i.amount)
			FROM installments i
			JOIN payment py ON i.pay_id = py.pay_id
			WHERE py.aid = a.aid
			) ) as 'Amount-Left', p.name
FROM appointment a
Join patient p ON p.pid = a.aid;

*/


/*
Add Data to Visited Tray

UPDATE appointment SET app_status='visited' WHERE aid = ? ;

*/

/*
Previous Treatments

SELECT * FROM treatments WHERE aid = ?;

*/

/*
If the patient needs specialist treatment which Dr Mulcahy cannot provide, she writes the 
name of an appropriate specialist on the filled visit card

UPDATE appointment SET app_status='reffered' WHERE aid=? ;

*/

/*
Reffering to Patient a Doctor with doctor id

INSERT INTO refferal_patients(aid, did)
VALUES	( ? , ?);


Adding Treatment Details

INSERT INTO treatment	(aid, details)
VALUES			( ? , ? );
*/






















