-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema clinic
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `clinic` ;

-- -----------------------------------------------------
-- Schema clinic
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `clinic` DEFAULT CHARACTER SET utf8 ;
USE `clinic` ;

-- -----------------------------------------------------
-- Table `clinic`.`patient`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`patient` (
  `pid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`pid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`appointment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`appointment` (
  `aid` INT NOT NULL AUTO_INCREMENT,
  `date_time` DATETIME NOT NULL DEFAULT NOW(),
  `due_amount` DOUBLE NOT NULL,
  `app_status` ENUM('booked', 'visited', 'cancel', 'reffered') NOT NULL,
  `pay_status` ENUM('paid', 'not-paid') NOT NULL,
  `pid` INT NOT NULL,
  PRIMARY KEY (`aid`, `pid`),
  INDEX `fk_appointment_patient_idx` (`pid` ASC) VISIBLE,
  CONSTRAINT `fk_appointment_patient`
    FOREIGN KEY (`pid`)
    REFERENCES `clinic`.`patient` (`pid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`address` (
  `address` VARCHAR(45) NOT NULL,
  `pid` INT NOT NULL,
  PRIMARY KEY (`pid`),
  CONSTRAINT `fk_address_patient1`
    FOREIGN KEY (`pid`)
    REFERENCES `clinic`.`patient` (`pid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`contact_no`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`contact_no` (
  `contact` VARCHAR(15) NOT NULL,
  `pid` INT NOT NULL,
  PRIMARY KEY (`pid`),
  CONSTRAINT `fk_contact_no_patient1`
    FOREIGN KEY (`pid`)
    REFERENCES `clinic`.`patient` (`pid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`treatment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`treatment` (
  `details` LONGTEXT NOT NULL,
  `aid` INT NOT NULL,
  CONSTRAINT `fk_treatment_appointment1`
    FOREIGN KEY (`aid`)
    REFERENCES `clinic`.`appointment` (`aid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`fee_guidelines`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`fee_guidelines` (
  `fgid` INT NOT NULL AUTO_INCREMENT,
  `description` LONGTEXT NOT NULL,
  PRIMARY KEY (`fgid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`payment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`payment` (
  `pay_id` INT NOT NULL AUTO_INCREMENT,
  `fgid` INT NOT NULL,
  `aid` INT NOT NULL,
  UNIQUE INDEX `pay_id_UNIQUE` (`pay_id` ASC) VISIBLE,
  PRIMARY KEY (`pay_id`, `fgid`, `aid`),
  INDEX `fk_payment_fee_guidelines1_idx` (`fgid` ASC) VISIBLE,
  INDEX `fk_payment_appointment1_idx` (`aid` ASC) VISIBLE,
  CONSTRAINT `fk_payment_fee_guidelines1`
    FOREIGN KEY (`fgid`)
    REFERENCES `clinic`.`fee_guidelines` (`fgid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_payment_appointment1`
    FOREIGN KEY (`aid`)
    REFERENCES `clinic`.`appointment` (`aid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`installments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`installments` (
  `payment_type` ENUM('cheque', 'card', 'cash', 'post') NOT NULL,
  `amount` DOUBLE NOT NULL,
  `date_time` DATETIME NOT NULL,
  `pay_id` INT NOT NULL,
  CONSTRAINT `fk_installments_payment1`
    FOREIGN KEY (`pay_id`)
    REFERENCES `clinic`.`payment` (`pay_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`doctor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`doctor` (
  `did` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `address` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`did`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `clinic`.`refferal_patients`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clinic`.`refferal_patients` (
  `aid` INT NOT NULL,
  `did` INT NOT NULL,
  PRIMARY KEY (`aid`, `did`),
  INDEX `fk_refferal_patients_doctor1_idx` (`did` ASC) VISIBLE,
  CONSTRAINT `fk_refferal_patients_appointment1`
    FOREIGN KEY (`aid`)
    REFERENCES `clinic`.`appointment` (`aid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_refferal_patients_doctor1`
    FOREIGN KEY (`did`)
    REFERENCES `clinic`.`doctor` (`did`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
